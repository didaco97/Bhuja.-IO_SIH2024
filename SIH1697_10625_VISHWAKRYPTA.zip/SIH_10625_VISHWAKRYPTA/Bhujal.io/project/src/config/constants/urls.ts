export const WEBSITE_URLS = [
  'https://cgwb.gov.in/documents/Ground%20Water%20Year%20Book%202021-22.pdf',
  'https://cgwb.gov.in/documents/Dynamic-GW-Resources-2022.pdf'
];