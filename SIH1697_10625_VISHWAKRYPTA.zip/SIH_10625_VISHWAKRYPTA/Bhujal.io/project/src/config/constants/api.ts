export const API_ENDPOINTS = {
  PERPLEXITY: 'https://api.perplexity.ai/chat/completions'
};