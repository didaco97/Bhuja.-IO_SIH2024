chatbot and bhujal.io are separate platforms required separate hosting

npm install

npm run dev